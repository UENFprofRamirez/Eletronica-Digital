### **Módulo 1: O Bloco de Memória - Flip-Flop SR Básico**

**Objetivo:** Entender o conceito fundamental de memória em eletrônica digital construindo um Flip-Flop SR, que pode armazenar um único bit de informação (ligado ou desligado).

**Conceitos-Chave:**

*   **Flip-Flop:** Um circuito biestável, o que significa que ele tem dois estados estáveis (0 ou 1). Ele permanece em um estado até que um sinal de entrada o force a mudar. É o "tijolo" básico da memória de computadores.
*   **Flip-Flop SR (Set-Reset):**
    *   **Entrada SET (S):** "Liga" a memória. Define a saída principal (Q) como 1.
    *   **Entrada RESET (R):** "Desliga" a memória. Redefine a saída principal (Q) como 0.
    *   **Estado de Memória:** Quando S e R são 0, o flip-flop "lembra" o último estado em que foi colocado.
    *   **Estado Inválido:** A condição em que S e R são 1 ao mesmo tempo deve ser evitada, pois torna a saída imprevisível.

**Componentes Necessários no Tinkercad:**

1.  **Placa de Ensaio (Protoboard):** 1
2.  **Fonte de Energia:** 1 (configurada para 5V)
3.  **CI 74HC02 (Quatro portas Lógicas NOR):** 1
4.  **Botão (Pushbutton):** 2 (um para SET, um para RESET)
5.  **LED:** 1 (qualquer cor)
6.  **Resistor 330 Ω:** 1 (para proteger o LED)
7.  **Resistor 10 kΩ:** 2 (pull-down para os botões)

**Passo a Passo da Montagem no Tinkercad:**

1.  **Alimentação:**
    *   Posicione a Placa de Ensaio e a Fonte de Energia no seu projeto.
    *   Conecte o polo positivo (+) da fonte de energia à linha vermelha (barramento de alimentação) da placa de ensaio.
    *   Conecte o polo negativo (-) da fonte de energia à linha azul (barramento de aterramento) da placa de ensaio.

2.  **Circuito Integrado (CI):**
    *   Adicione o CI **74HC02** no centro da placa, com o chanfro (meia-lua) para cima.
    *   Conecte o pino 14 (VCC) do CI ao barramento de alimentação (+5V).
    *   Conecte o pino 7 (GND) do CI ao barramento de aterramento.

3.  **Botões (Entradas S e R):**
    *   Posicione os dois botões na placa.
    *   **Botão SET (S):**
        *   Conecte um terminal do botão ao barramento de alimentação (+5V).
        *   Conecte o outro terminal (na mesma fileira) ao **pino 2** do CI 74HC02.
        *   Conecte um resistor de 10 kΩ do **pino 2** ao barramento de aterramento (isso é o resistor de pull-down, garantindo que a entrada seja 0 quando o botão não está pressionado).
    *   **Botão RESET (R):**
        *   Conecte um terminal do segundo botão ao barramento de alimentação (+5V).
        *   Conecte o outro terminal ao **pino 6** do CI 74HC02.
        *   Conecte um resistor de 10 kΩ do **pino 6** ao barramento de aterramento.

4.  **Lógica do Flip-Flop (Conexões Cruzadas):**
    *   Esta é a parte principal do circuito! Estamos usando duas das quatro portas NOR do CI.
    *   Conecte o **pino 1** (saída da primeira porta NOR) ao **pino 5** (entrada da segunda porta NOR).
    *   Conecte o **pino 4** (saída da segunda porta NOR) ao **pino 3** (entrada da primeira porta NOR).

5.  **LED de Saída (Q):**
    *   A saída do nosso flip-flop será o pino 1. Vamos chamá-la de **Q**.
    *   Conecte o resistor de 330 Ω do **pino 1** do CI a uma fileira vazia da placa.
    *   Conecte o terminal longo (anodo) do LED na mesma fileira do resistor.
    *   Conecte o terminal curto (catodo) do LED ao barramento de aterramento.

**Como Testar:**

1.  **Inicie a Simulação** no Tinkercad. O LED provavelmente começará apagado.
2.  **Pressione e solte o botão SET:** O LED deve acender. Note que, mesmo depois de soltar o botão, o LED **permanece aceso**. O circuito "lembrou" o estado SET.
3.  **Pressione e solte o botão RESET:** O LED deve apagar. Mesmo depois de soltar, ele **permanece apagado**. O circuito "lembrou" o estado RESET.
4.  **Experimente:** Pressione SET novamente. O LED acende. Pressione SET várias vezes. Nada muda. Pressione RESET. O LED apaga. O circuito só muda de estado quando a entrada oposta é ativada.

**Parabéns!** Você construiu sua primeira célula de memória. Este é o alicerce para contadores, registradores e a memória do computador.