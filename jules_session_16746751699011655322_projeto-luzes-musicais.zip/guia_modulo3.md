### **Módulo 3: A Sequência de Luzes - Construindo um Registrador de Deslocamento (Versão Corrigida)**

**Objetivo:** Interligar vários Flip-Flops JK para criar um Registrador de Deslocamento (Shift Register), que pode mover um bit de dados através de uma cadeia de LEDs a cada pulso de clock.

**Conceitos-Chave:**

*   **Registrador de Deslocamento (Shift Register):** Um circuito sequencial que consiste em uma cadeia de flip-flops conectados em cascata. A saída de um flip-flop é conectada à entrada do próximo.
*   **Flip-Flop tipo D:** Ao conectar a entrada J a uma entrada de dados (D) e a entrada K à sua inversão (!D), um flip-flop JK se comporta como um flip-flop D (Data). A saída Q simplesmente recebe o valor de D a cada pulso de clock. É a base de um registrador de deslocamento.

**Componentes Necessários no Tinkercad:**

1.  **Placa de Ensaio:** 1
2.  **Fonte de Energia:** 1 (5V)
3.  **CI 74HC76 (Dois Flip-Flops JK):** 2 (usaremos 4 flip-flops no total)
4.  **CI 74HC04 (Inversores Hex):** 1 **(Adicionado para correção)**
5.  **Botão (Pushbutton):** 2 (um para o CLOCK, um para a ENTRADA DE DADOS)
6.  **LED:** 4 (cores diferentes para um efeito melhor)
7.  **Resistor 330 Ω:** 4 (um para cada LED)
8.  **Resistor 10 kΩ:** 2 (pull-down para os botões)

**Passo a Passo da Montagem no Tinkercad:**

1.  **Posicione os Componentes:**
    *   Coloque os dois CIs **74HC76** e o CI **74HC04** na placa de ensaio.
    *   Conecte a alimentação para **todos os três CIs**: +5V nos pinos VCC (pino 5 nos 74HC76, pino 14 no 74HC04) e Terra nos pinos GND (pino 13 nos 74HC76, pino 7 no 74HC04).
    *   Desative os PRESETS e CLEARS de todos os quatro flip-flops, conectando os pinos 2, 3, 7 e 8 de **ambos os CIs 74HC76** ao +5V.

2.  **Sinal de Clock Comum:**
    *   Conecte um botão para ser o CLOCK.
    *   Ligue a saída deste botão a **todos** os pinos de CLK dos flip-flops: pino 1 e pino 6 do primeiro CI 74HC76, e pino 1 e pino 6 do segundo CI 74HC76.

3.  **Entrada de Dados Corrigida (Serial In):**
    *   Use o segundo botão como a entrada de dados (DATA IN).
    *   Conecte a saída deste botão diretamente ao pino **J** do **primeiro** flip-flop (Pino 4 do primeiro CI 74HC76).
    *   Agora, conecte a mesma saída do botão à entrada de um dos inversores do 74HC04 (por exemplo, **pino 1**).
    *   Conecte a saída desse inversor (neste caso, **pino 2** do 74HC04) ao pino **K** do **primeiro** flip-flop (Pino 16 do primeiro CI 74HC76).
    *   *Explicação:* Com esta correção, se o botão DATA IN for '1', J=1 e K=0 (modo SET). Se o botão for '0', J=0 e K=1 (modo RESET). Isso garante que o flip-flop carregue o dado correto a cada pulso, em vez de ficar no modo "Hold".

4.  **Conectando a Cadeia (Cascata):**
    *   Para os flip-flops seguintes, faremos a mesma lógica D (J=Q_anterior, K=!Q_anterior) para propagar o dado.
    *   **FF1 -> FF2:** Conecte a saída **Q** do primeiro flip-flop (pino 15, CI 1) à entrada **J** do segundo (pino 9, CI 1). Conecte a saída **!Q** (pino 14, CI 1) à entrada **K** do segundo (pino 12, CI 1).
    *   **FF2 -> FF3:** Conecte a saída **Q** do segundo flip-flop (pino 11, CI 1) à entrada **J** do terceiro (pino 4, CI 2). Conecte a saída **!Q** (pino 10, CI 1) à entrada **K** do terceiro (pino 16, CI 2).
    *   **FF3 -> FF4:** Conecte a saída **Q** do terceiro flip-flop (pino 15, CI 2) à entrada **J** do quarto (pino 9, CI 2). Conecte a saída **!Q** (pino 14, CI 2) à entrada **K** do quarto (pino 12, CI 2).

5.  **Saídas de Luz (Parallel Out):**
    *   Conecte um LED (com seu resistor) à saída **Q** de cada flip-flop, como antes:
        *   **LED 1:** Pino 15 do CI 1
        *   **LED 2:** Pino 11 do CI 1
        *   **LED 3:** Pino 15 do CI 2
        *   **LED 4:** Pino 11 do CI 2

**Como Testar:**

1.  **Inicie a Simulação.** Todos os LEDs devem estar apagados.
2.  **Pressione e segure o botão DATA IN.**
3.  **Dê um pulso no CLOCK.** O primeiro LED deve acender.
4.  **Solte o botão DATA IN.**
5.  **Dê outro pulso no CLOCK.** O primeiro LED agora deve apagar e o segundo acender! O '1' se moveu corretamente.
6.  **Continue pulsando o CLOCK.** Você verá o bit '1' "caminhar" pelo circuito e desaparecer no final, pois a entrada de dados agora é '0'. O circuito agora funciona!

Agora sim temos uma sequência correta! O próximo passo será adicionar som a essa sequência.