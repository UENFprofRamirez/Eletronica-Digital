### **Módulo 5: Tornando-o Interativo - O Jogo**

**Objetivo:** Automatizar o sequenciador com um clock gerado por um CI 555, adicionar controle de velocidade e um botão de reset, transformando o circuito em um jogo musical interativo.

**Conceitos-Chave:**

*   **CI 555 (Timer):** Um dos circuitos integrados mais versáteis já criados. Vamos usá-lo no modo "astável" para gerar um sinal de clock contínuo e pulsante (uma onda quadrada).
*   **Modo Astável:** Nesta configuração, o 555 gera pulsos em uma frequência determinada por dois resistores e um capacitor. Ele não tem um estado estável, alternando continuamente entre ligado e desligado.
*   **Potenciômetro:** Um resistor variável. Ao girá-lo, alteramos sua resistência, o que, no nosso circuito, mudará a frequência do clock do 555, controlando a velocidade da música.
*   **Reset Global (Clear):** Os Flip-Flops JK têm uma entrada assíncrona chamada CLEAR (ou RESET). Ao ativá-la (com nível BAIXO), a saída Q é forçada para 0 imediatamente, independentemente do clock. Usaremos isso para limpar todo o nosso registrador de uma só vez.

**Componentes Adicionais Necessários:**

1.  **CI NE555 (Timer):** 1
2.  **Potenciômetro:** 1 (100 kΩ é um bom valor)
3.  **Capacitor Eletrolítico:** 1 (10 µF)
4.  **Resistor:** 1 (1 kΩ)
5.  **Botão (Pushbutton):** 1 (para o RESET)
6.  **Resistor 10 kΩ:** 1 (pull-up para o botão de RESET)

**Passo a Passo da Montagem (Modificando o Circuito do Módulo 4):**

1.  **Remova o Botão de Clock:** Desconecte o botão que estava servindo como clock manual, juntamente com seu resistor de pull-down. A linha de clock dos flip-flops está agora livre.

2.  **Construa o Circuito do Clock 555:**
    *   Posicione o CI 555 na placa.
    *   Conecte o **pino 8 (VCC)** ao +5V e o **pino 1 (GND)** ao terra.
    *   Conecte o **pino 4 (Reset)** ao +5V para mantê-lo ativo.
    *   Conecte o **pino 2 (Trigger)** ao **pino 6 (Threshold)**.
    *   Conecte o capacitor de **10 µF** entre o **pino 2** e o terra (lembre-se da polaridade!).
    *   Conecte o resistor de **1 kΩ** entre o **+5V** e o **pino 7 (Discharge)**.
    *   Conecte o **potenciômetro de 100 kΩ**:
        *   Conecte o **terminal 1** ao **pino 7**.
        *   Conecte o **terminal 2 (central)** ao **pino 6**.
        *   O terminal 3 pode ficar desconectado ou ligado ao terminal 2.

3.  **Conecte o Novo Clock Automático:**
    *   A saída do 555 é o **pino 3 (OUT)**. Conecte este pino à linha de clock comum que vai para todos os pinos de clock (CLK) dos flip-flops (pinos 1 e 6 de ambos os 74HC76).

4.  **Adicione o Botão de Reset Global:**
    *   Os pinos de CLEAR dos nossos flip-flops são os pinos 3 e 8 de ambos os CIs. Eles estavam conectados ao +5V para serem desativados. Desconecte-os do +5V.
    *   Conecte um resistor de **10 kΩ (pull-up)** dessa linha de CLEAR (que une os pinos 3 e 8 de ambos os CIs) para o **+5V**.
    *   Posicione o novo botão. Conecte um terminal dele a essa mesma linha de CLEAR e o outro terminal ao **terra**.

**Como Testar e Jogar:**

1.  **Inicie a Simulação.** A sequência começará a tocar e as luzes a piscar automaticamente! A velocidade inicial dependerá da posição do potenciômetro.
2.  **Controle a Velocidade:** Clique no potenciômetro e gire-o. Você verá a velocidade das luzes e o ritmo da música aumentarem e diminuírem.
3.  **Limpe a Sequência:** Pressione o novo botão de **RESET**. Todas as luzes se apagarão e o som parará instantaneamente.
4.  **Crie sua Melodia:** Com a sequência limpa, segure o botão **DATA IN**. As luzes começarão a acender uma a uma na velocidade do clock. Solte o botão para inserir "pausas" (zeros). Crie padrões rítmicos e melódicos!

Parabéns! Você construiu um sequenciador de luzes musicais totalmente interativo e funcional. Agora temos todos os blocos para montar o guia final para o professor.