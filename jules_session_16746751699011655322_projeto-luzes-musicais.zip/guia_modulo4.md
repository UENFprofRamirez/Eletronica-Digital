### **Módulo 4: Adicionando a Música - O Som da Lógica**

**Objetivo:** Modificar o registrador de deslocamento para que, além de acender uma sequência de luzes, ele produza uma sequência de notas musicais, uma para cada luz.

**Conceitos-Chave:**

*   **Buzzer Piezoelétrico:** Um componente que converte um sinal elétrico em som. Quando aplicamos uma tensão nele, um pequeno cristal interno vibra, produzindo um tom.
*   **Tom vs. Corrente (no Tinkercad):** Uma característica útil do simulador Tinkercad é que o buzzer piezoelétrico produzirá tons diferentes (notas mais graves ou mais agudas) dependendo da corrente que o atravessa. Podemos controlar essa corrente facilmente usando resistores de valores diferentes.
*   **Mixagem Passiva:** Vamos conectar a saída de cada flip-flop ao mesmo buzzer, cada um através de seu próprio resistor. Isso cria um "mixer" simples, onde o sinal do flip-flop que está em nível ALTO (1) dominará e definirá o som a ser tocado.

**Componentes Adicionais Necessários:**

1.  **Buzzer Piezoelétrico:** 1
2.  **Resistores de valores variados:** 4 (sugestão: 1 kΩ, 470 Ω, 220 Ω, 100 Ω)

**Passo a Passo da Montagem (Modificando o Circuito do Módulo 3):**

1.  **Posicione o Buzzer:**
    *   Adicione o buzzer piezoelétrico na sua placa de ensaio.
    *   Conecte o terminal negativo (-) do buzzer diretamente ao barramento de aterramento (GND).

2.  **Conecte a Primeira Nota (a mais aguda):**
    *   Pegue um resistor de **1 kΩ**.
    *   Conecte um terminal do resistor na mesma linha da saída Q do **primeiro flip-flop** (onde o LED 1 já está conectado).
    *   Conecte o outro terminal do resistor ao terminal positivo (+) do buzzer.

3.  **Conecte a Segunda Nota:**
    *   Pegue um resistor de **470 Ω**.
    *   Conecte um terminal na linha de saída Q do **segundo flip-flop** (LED 2).
    *   Conecte o outro terminal ao terminal positivo (+) do buzzer (no mesmo ponto que o resistor anterior).

4.  **Conecte a Terceira Nota:**
    *   Pegue um resistor de **220 Ω**.
    *   Conecte um terminal na linha de saída Q do **terceiro flip-flop** (LED 3).
    *   Conecte o outro terminal ao positivo do buzzer.

5.  **Conecte a Quarta Nota (a mais grave):**
    *   Pegue um resistor de **100 Ω**.
    *   Conecte um terminal na linha de saída Q do **quarto flip-flop** (LED 4).
    *   Conecte o outro terminal ao positivo do buzzer.

**Como Testar:**

1.  **Inicie a Simulação.** Lembre-se de usar fones de ouvido ou ligar o som do seu computador!
2.  **Pressione e segure o botão DATA IN e dê um pulso no CLOCK.** O primeiro LED acenderá e você ouvirá a primeira nota (a mais aguda).
3.  **Solte o DATA IN e continue pulsando o CLOCK.** A cada pulso, a luz se moverá para o próximo LED e você ouvirá uma nota diferente, cada vez mais grave, seguindo a sequência: NOTA 1 -> NOTA 2 -> NOTA 3 -> NOTA 4.
4.  **Experimente:** Tente inserir padrões diferentes. Por exemplo, insira um '1', pulse o clock duas vezes, insira outro '1'. Você agora terá duas luzes e dois sons se movendo pelo circuito, criando harmonias simples.

Nosso projeto agora tem luz e som! Estamos a um passo de transformá-lo em um jogo interativo.