### **Módulo 2: Controle e Versatilidade - O Flip-Flop JK Sincronizado**

**Objetivo:** Evoluir do Flip-Flop SR para o JK, introduzindo o controle síncrono através de um sinal de Clock e explorando a poderosa função de alternância (toggle).

**Conceitos-Chave:**

*   **Flip-Flop JK:** Uma versão aprimorada do SR. A entrada **J** se comporta como a SET, e a entrada **K** como a RESET.
*   **O Problema do SR Resolvido:** No Flip-Flop JK, a condição de J=1 e K=1 não é inválida. Em vez disso, ela tem uma função especial.
*   **Sinal de Clock (CLK):** É um sinal pulsante que dita o ritmo do circuito. O Flip-Flop JK só muda de estado no momento exato em que o pulso de clock ocorre (neste caso, na *borda de descida*, quando o sinal vai de 1 para 0). Isso garante que todos os componentes de um sistema maior mudem em sincronia.
*   **Função Toggle (Alternância):** Quando J=1 e K=1, a cada pulso de clock, a saída **Q** inverte seu estado atual. Se estava em 0, vai para 1. Se estava em 1, vai para 0. É como um interruptor de luz.

**Componentes Necessários no Tinkercad:**

1.  **Placa de Ensaio:** 1
2.  **Fonte de Energia:** 1 (configurada para 5V)
3.  **CI 74HC76 (Dois Flip-Flops JK):** 1
4.  **Botão (Pushbutton):** 3 (para J, K e CLOCK)
5.  **LED:** 1
6.  **Resistor 330 Ω:** 1 (para o LED)
7.  **Resistor 10 kΩ:** 3 (pull-down para os botões)

**Passo a Passo da Montagem no Tinkercad:**

1.  **Alimentação:**
    *   Posicione e conecte a Fonte de Energia (+5V e Terra) à Placa de Ensaio, como no módulo anterior.

2.  **Circuito Integrado (CI):**
    *   Adicione o CI **74HC76**. **Atenção:** A pinagem é diferente!
    *   Conecte o pino **5 (VCC)** ao barramento de +5V.
    *   Conecte o pino **13 (GND)** ao aterramento.

3.  **Desativando Set e Reset Assíncronos:**
    *   Para que o flip-flop obedeça apenas ao Clock, precisamos desativar as entradas PRESET (pino 2) e CLEAR (pino 3). Para isso, conecte ambos os pinos diretamente ao +5V.

4.  **Botões (Entradas J, K e CLK):**
    *   Posicione os três botões.
    *   **Botão J:** Conecte ao **pino 4 (1J)**, com seu resistor de pull-down de 10 kΩ para o terra.
    *   **Botão K:** Conecte ao **pino 16 (1K)**, com seu resistor de pull-down.
    *   **Botão CLOCK:** Conecte ao **pino 1 (1CLK)**, com seu resistor de pull-down.

5.  **LED de Saída (Q):**
    *   A saída principal é o **pino 15 (1Q)**.
    *   Conecte o LED (com seu resistor de 330 Ω) a este pino para visualizar o estado.

**Como Testar:**

1.  **Inicie a Simulação.**
2.  **Modo Memória (J=0, K=0):** Não pressione J nem K. Pressione o botão de **CLOCK** várias vezes. O LED não deve mudar de estado.
3.  **Modo Set (J=1, K=0):** Segure o botão **J**. Agora, pressione e solte o **CLOCK**. O LED deve acender.
4.  **Modo Reset (J=0, K=1):** Segure o botão **K**. Pressione e solte o **CLOCK**. O LED deve apagar.
5.  **Modo Toggle (J=1, K=1):** Segure **ambos** os botões **J e K**. Agora, cada vez que você pressionar e soltar o **CLOCK**, o LED vai **alternar** entre aceso e apagado.

Com este módulo, os alunos verão o controle preciso que o clock oferece e a funcionalidade que torna o JK a base para contadores e sequenciadores de luzes.