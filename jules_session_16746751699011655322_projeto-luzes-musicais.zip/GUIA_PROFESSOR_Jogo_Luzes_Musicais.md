# PROJETO LÚDICO: Guia do Professor para o Jogo de Luzes Musicais com Flip-Flops no Tinkercad

## Introdução

Bem-vindo, Professor!

Este guia oferece um projeto prático e modular para ensinar eletrônica digital de forma lúdica no Tinkercad. O projeto "Jogo de Luzes Musicais" foi desenhado para ser construído em etapas, garantindo que os alunos absorvam cada conceito antes de avançar.

## Estrutura do Projeto

O projeto é dividido em cinco módulos sequenciais. Cada módulo possui seu próprio guia detalhado com objetivos, conceitos-chave, lista de componentes e um passo a passo para a montagem no Tinkercad.

### **Índice dos Módulos:**

*   **[Módulo 1: O Bloco de Memória - Flip-Flop SR Básico](./guia_modulo1.md)**
    *   *Objetivo:* Construir a unidade fundamental da memória digital, o Flip-Flop SR, e entender os estados SET e RESET.

*   **[Módulo 2: Controle e Versatilidade - O Flip-Flop JK Sincronizado](./guia_modulo2.md)**
    *   *Objetivo:* Introduzir o Flip-Flop JK, o conceito de CLOCK e a função de TOGGLE (alternância).

*   **[Módulo 3: A Sequência de Luzes - Construindo um Registrador de Deslocamento](./guia_modulo3.md)**
    *   *Objetivo:* Conectar múltiplos flip-flops para criar uma sequência de luzes que "caminham" a cada pulso de clock. **Este módulo inclui uma correção importante para o funcionamento do circuito.**

*   **[Módulo 4: Adicionando a Música - O Som da Lógica](./guia_modulo4.md)**
    *   *Objetivo:* Adicionar um buzzer para que cada luz na sequência produza uma nota musical diferente.

*   **[Módulo 5: Tornando-o Interativo - O Jogo](./guia_modulo5.md)**
    *   *Objetivo:* Automatizar o CLOCK com um timer 555, adicionar controle de velocidade e um botão de RESET para criar um instrumento musical interativo.

## Como Usar

Recomendamos seguir os módulos na ordem apresentada. Cada arquivo `.md` é autônomo para a sua respectiva etapa.

Bom trabalho!